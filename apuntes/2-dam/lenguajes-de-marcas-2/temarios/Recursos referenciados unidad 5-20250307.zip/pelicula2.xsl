﻿<?xml version="1.0"?>
<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	version="1.0">
<xsl:template match="/">
<html>
   <head>
      <title>
   	<xsl:value-of select="/pelicula/titulo" />
      </title>
   </head>
   <body>
      <h1>Ficha Pelicula</h1>
      <u>Titulo:</u>
      <strong><xsl:value-of select="/pelicula/titulo"/></strong>
      <br/>
      <u>Director:</u>
      <xsl:value-of select="/pelicula/director"/>
      <br/>
      <u>Protagonista:</u>
      <xsl:value-of select="pelicula/actores/actor"/>
      <br/>
   </body>
</html> 
</xsl:template>
</xsl:stylesheet>