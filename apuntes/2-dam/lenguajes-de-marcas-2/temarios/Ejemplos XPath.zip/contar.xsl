﻿<?xml version="1.0"?>
<xsl:stylesheet
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	version="1.0">

<xsl:template match="/">
<html>
<body>
<p> Número Total de libros:</p>        
        <xsl:value-of select="count(/libros/libro)"/>
</body>
</html>
</xsl:template>
</xsl:stylesheet>