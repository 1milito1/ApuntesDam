import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Random;

/**
 *
 * @author milio
 */
public class Cliente {
    private static final String direccionServidor = "127.0.0.1";
    private static final int servidorPORT = 12345;

    public static void main(String[] args) {
        try (Socket socket = new Socket(direccionServidor, servidorPORT);
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            Random random = new Random();
            while (true) {
                double temperatura = 15 + random.nextDouble() * 20;
                out.println(temperatura);
                System.out.println("Enviado: " + temperatura);

                String response = in.readLine();
                System.out.println("Respuesta del servidor: " + response);

                Thread.sleep(5000);

            }
        } catch (IOException | InterruptedException e) {
            System.err.println("Error en el cliente" + e.getMessage());
        }
    }

}
