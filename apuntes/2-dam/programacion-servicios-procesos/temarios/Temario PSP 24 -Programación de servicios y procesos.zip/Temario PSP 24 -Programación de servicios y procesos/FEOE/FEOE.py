import threading
import time
import random

class Filosofo(threading.Thread):
    def __init__(self, nombre, palillo_izq, palillo_der):
        super().__init__()
        self.nombre = nombre
        self.palillo_izq = palillo_izq
        self.palillo_der = palillo_der

    def run(self):
        while True:
            print(f"{self.nombre} está pensando.")
            time.sleep(random.uniform(1, 3))
            print(f"{self.nombre} tiene hambre.")
            self.comer()

    def comer(self):
        # COMPLETAR: Coger primero un palillo, luego el otro (usa with)
        # Asegúrate de evitar interbloqueo usando un orden consistente de adquisición
        try:
            with self.palillo_izq:
                print(f"{self.nombre} ha cogido el palillo izquierdo.")
                with self.palillo_der:
                    print(f"{self.nombre} ha cogido el palillo derecho.")

                    print(f"{self.nombre} está comiendo.")
                    time.sleep(random.uniform(1, 3))
        except Exception as e:
            print(f"Error en {self.nombre}: {e}")
        finally:
             pass

N = 5
palillos = [threading.Lock() for _ in range(N)]
filosofos = [
    Filosofo(f"Filósofo {i}", palillos[i], palillos[(i + 1) % N])
    for i in range(N)
]

for f in filosofos:
    f.start()