# Importo la clase Path para manejar rutas y el módulo csv para exportar
from pathlib import Path
import csv

# FUNCIÓN 1
# Lee un fichero de texto con ancho fijo y devuelve una lista de tuplas.
def leer_empleados_ancho_fijo(ruta):
    empleados = [] # Lista vacía donde se guardarán las tuplas

    # Abro el archivo en modo lectura
    with open(ruta, 'r', encoding='utf-8') as e:
        for linea in e: # Extrae campos por posiciones fijas y elimina espacios con strip()
            empleado = linea[0:3].strip()
            nombre = linea[3:13].strip()
            apellido = linea[13:23].strip()
            salario = int(linea[23:28].strip()) # lo convierto a int
            empleados.append((empleado, nombre, apellido, salario)) # Lo añado como tupla
    return empleados  # Devuelve la lista de empleados como tuplas

# FUNCIÓN 2
# Agrega un nuevo empleado al fichero, manteniendo el formato de ancho fijo
def agregar_empleado(ruta, empleado):
    empleados = leer_empleados_ancho_fijo(ruta)

    # Compruebo que el empleado introducido no sea repetido
    if empleado in empleados:
        print(f"\nEmpleado {empleado[1]} {empleado[2]} ya existe. No se agregó.")
        return

    # Compruebo si el archivo existe, para saber si usamos 'append' (agregar) o 'write' (escrbir desde 0)
    if Path(ruta).exists():
        modo = 'a' # Añadir al final
    else:
        modo = 'w' # Crear uno nuevo

    # Abro el archivo con el modo seleccionado
    with open(ruta, modo, encoding='utf-8') as e:
        # Se escribe cada campo con su ancho correspondiente, alineado a la izquierda
        e.write(f"{empleado[0]:<3}{empleado[1]:<10}{empleado[2]:<10}{empleado[3]:<5}\n")

# FUNCIÓN 3
# Calculo el salario medio de los empleados
def salario_medio(empleados):
    if not empleados: 
        return 0 # Para evitar división por cero

    # Sumo todos los salarios (están en la posición 3 de cada tupla)
    total_salarios = sum(emp[3] for emp in empleados)
    media = total_salarios / len(empleados) # Divido entre el número de empleados (len para saber nº de empleados)
    return media # Devuelvo la media

# FUNCIÓN 4
# Exporta la lista de empleados a un archivo CSV
def exportar_csv(ruta_salida, empleados):
    with open(ruta_salida, 'w', newline='', encoding='utf-8') as csvfile: # newline='' evita líneas en blanco adicionales en el CSV
        writer = csv.writer(csvfile) # Preparo el archivo para poder escribir datos en formato CSV

        # Se escribe la cabecera del archivo CSV
        writer.writerow(['Id', 'Nombre', 'Apellido', 'Salario']) # Cabecera

        # Escribo los datos de cada empleado
        for emp in empleados:
            writer.writerow(emp)

# MAIN
if __name__ == "__main__":
    # Rutas a los archivos
    ruta_txt = 'empleados.txt'
    ruta_csv = 'empleados.csv'

    # 1. Leer empleados desde el archivo de ancho fijo
    empleados = leer_empleados_ancho_fijo(ruta_txt)
    print("Empleados leídos:")
    for e in empleados:
        print(e)

    # 2. Agregar un nuevo empleado
    nuevo = ('005', 'Mario', 'López', 27000)
    agregar_empleado(ruta_txt, nuevo)

    # 3. Leer de nuevo después de agregar
    empleados = leer_empleados_ancho_fijo(ruta_txt)
    for e in empleados:
        print(e)

    # 4. Calcular el salario medio
    media = salario_medio(empleados)
    print(f"\nSalario medio: {media:.2f}€")

    # 5. Exportar a CSV
    exportar_csv(ruta_csv, empleados)
    print(f"\nDatos exportados a {ruta_csv}")