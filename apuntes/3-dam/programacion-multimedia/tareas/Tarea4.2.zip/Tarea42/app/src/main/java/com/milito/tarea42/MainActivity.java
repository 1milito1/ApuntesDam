package com.milito.tarea42;

//Alumno: Emilio José García Esteban

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Spinner spColores;
    private TextView tvMensaje;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);


        spColores = findViewById(R.id.spColores);
        tvMensaje = findViewById(R.id.tvMensaje);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.lista_colores,
                android.R.layout.simple_spinner_item
        );

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spColores.setAdapter(adapter);
        spColores.setOnItemSelectedListener(new manejadorColor());
    }

    private class manejadorColor implements AdapterView.OnItemSelectedListener {

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            String colorSeleccionado = parent.getItemAtPosition(position).toString();
            String mensaje = getString(R.string.mensaje);
            tvMensaje.setText(mensaje + colorSeleccionado);

            if(colorSeleccionado.equals("Rojo")){
                tvMensaje.setTextColor(getResources().getColor(R.color.rojo));
            }else if(colorSeleccionado.equals("Azul")){
                tvMensaje.setTextColor(getResources().getColor(R.color.azul));
            }else if(colorSeleccionado.equals("Verde")){
                tvMensaje.setTextColor(getResources().getColor(R.color.verde));
            }else if(colorSeleccionado.equals("Naranja")) {
                tvMensaje.setTextColor(getResources().getColor(R.color.naranja));
            }else{
                tvMensaje.setTextColor(getResources().getColor(R.color.black));
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
            tvMensaje.setText("");
        }
    }
}