package com.milito.adiviniarnumero;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {

    private EditText etNumero;
    private TextView tvPuntuacion;
    private TextView tvMayorMenor;
    private int numeroSecreto;
    private int aciertos;
    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        etNumero = findViewById(R.id.etNumero);
        tvPuntuacion = findViewById(R.id.tvPuntuacion);
        tvMayorMenor = findViewById(R.id.tvMayorMenor);

        preferences = getSharedPreferences("MisDatos", Context.MODE_PRIVATE);
        aciertos = preferences.getInt("aciertos", 0);
        tvPuntuacion.setText("Puntuación: " + aciertos);

        generarNuevoNumero();

        findViewById(R.id.btnComprobar).setOnClickListener(v -> {
            validarYcomprobar();
        });

    }

    private void generarNuevoNumero(){

        numeroSecreto = (int) (Math.random() * 25) +1;

        try(OutputStreamWriter osw = new OutputStreamWriter(openFileOutput("secreto.txt", MODE_PRIVATE))){
            osw.write(String.valueOf(numeroSecreto));
        }catch (IOException e){
            e.printStackTrace();

        }
    }

    private void validarYcomprobar(){

    String texto = etNumero.getText().toString().trim();

    if (texto.isEmpty()) {
        Toast.makeText(this, "Introduce un número", Toast.LENGTH_SHORT).show();
        return;
    }



    try {

        int userNum = Integer.parseInt(texto);

        if (userNum == numeroSecreto) {
            aciertos++;
            preferences.edit().putInt("aciertos", aciertos).apply();
            tvPuntuacion.setText("Puntuación: " + aciertos);
            android.view.animation.Animation animacion = android.view.animation.AnimationUtils.loadAnimation(this, R.anim.parpadeo);


            try (BufferedReader br = new BufferedReader(new InputStreamReader(openFileInput("secreto.txt")))) {
                String numFichero = br.readLine();
                Toast.makeText(this, "¡Correcto! El número era: " + numFichero, Toast.LENGTH_SHORT).show();

                etNumero.setText("");


                tvMayorMenor.setText("¡¡¡¡CORRECTO!!!!");
                tvMayorMenor.setBackgroundColor(getResources().getColor(R.color.verde));
                tvMayorMenor.setTextSize(50);
                findViewById(R.id.tvMayorMenor).startAnimation(animacion);


                new android.os.Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        tvMayorMenor.setText("");
                        tvMayorMenor.setBackgroundColor(android.graphics.Color.TRANSPARENT);
                        tvMayorMenor.setTextSize(20);

                    }
                }, 2000);

            } catch (IOException e) {
                e.printStackTrace();
            }

            generarNuevoNumero();
            etNumero.setText("");

        } else if (userNum < numeroSecreto) {
            Toast.makeText(this, "El número es MAYOR", Toast.LENGTH_SHORT).show();
            etNumero.setText("");
            tvMayorMenor.setText("El número secreto es Mayor");
        }else if(userNum > 25){
            Toast.makeText(this, "El número debe estar entre 1 y 25", Toast.LENGTH_SHORT).show();
            etNumero.setText("");
            tvMayorMenor.setText("El número no está entre el 1 y 25");
        }else  {
            Toast.makeText(this, "El número es MENOR", Toast.LENGTH_SHORT).show();
            etNumero.setText("");
            tvMayorMenor.setText("El número secreto es Menor");

        }
    } catch (NumberFormatException e) {

        Toast.makeText(this, "Introduce un número válido", Toast.LENGTH_SHORT).show();
    }


    }
}