package com.milito.tarea33;

//Alumno: Emilio José García Esteban

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private RadioGroup rbCurso;
    private RadioButton rbAndroid;
    private RadioButton rbPython;
    private RadioButton rbUnity;
    private CheckBox cbOro;
    private CheckBox cbPlata;
    private Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        rbCurso = findViewById(R.id.rgCurso);
        rbAndroid = findViewById(R.id.rbAndroid);
        rbPython = findViewById(R.id.rbPython);
        rbUnity = findViewById(R.id.rbUnity);
        cbOro = findViewById(R.id.cbOro);
        cbPlata = findViewById(R.id.cbPlata);
        btnCalcular = findViewById(R.id.btnCalcular);

        btnCalcular.setOnClickListener(this::calcular);

    }

    public void calcular(View view) {
        double precio = 0.0;
        double descuento = 0.0;
        String curso = "";

        int cursoSeleccionado = rbCurso.getCheckedRadioButtonId();

        if (cursoSeleccionado == rbAndroid.getId()){
            precio = 150;
            curso = "Android (150€)";
        }else if (cursoSeleccionado == rbPython.getId()) {
            precio = 120;
            curso = "Python (120€)";
        }else if (cursoSeleccionado == rbUnity.getId()) {
            precio = 100;
            curso = "Unity (100€)";
        }else {
            Toast.makeText(this, "Debes seleccionar un curso", Toast.LENGTH_SHORT).show();
        }


        if (cbOro.isChecked()) {
            descuento += 0.10;
        }
        if (cbPlata.isChecked()) {
            descuento += 0.05;
        }
        double descuentoAplicado = precio * descuento;
        double precioFinal = precio - descuentoAplicado;

        String mensaje = "Curso: " + curso +  ", Precio Final del curso: " + precioFinal + "€";


        Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show();
    }
}