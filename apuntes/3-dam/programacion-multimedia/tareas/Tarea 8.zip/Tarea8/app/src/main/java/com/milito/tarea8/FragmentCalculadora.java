package com.milito.tarea8;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


public class FragmentCalculadora extends Fragment {

    private EditText etNum1, etNum2;
    private RadioGroup rgGrupo;
    private RadioButton rbSumar, rbRestar, rbMultiplicar, rbDividir;
    private TextView tvResultado;
    private Button btnOperar;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_calculadora, container, false);

        etNum1 = v.findViewById(R.id.etNum1);
        etNum2 = v.findViewById(R.id.etNum2);
        rgGrupo = v.findViewById(R.id.rgGrupo);
        rbSumar = v.findViewById(R.id.rbSumar);
        rbRestar = v.findViewById(R.id.rbRestar);
        rbMultiplicar = v.findViewById(R.id.rbMultiplicar);
        rbDividir = v.findViewById(R.id.rbDividir);
        tvResultado = v.findViewById(R.id.tvResultado);
        btnOperar = v.findViewById(R.id.btnOperar);

        btnOperar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String et1 = etNum1.getText().toString();
                String et2 = etNum2.getText().toString();

                if (!et1.isEmpty() && !et2.isEmpty()){

                    double num1 = Double.parseDouble(et1);
                    double num2 = Double.parseDouble(et2);
                    double resultado = 0;
                    String mensaje ="";

                    int idSeleccionado = rgGrupo.getCheckedRadioButtonId();

                    if (idSeleccionado == R.id.rbSumar){
                        resultado = num1 + num2;
                        mensaje = "La suma es: \n" + resultado;
                    } else if (idSeleccionado == R.id.rbRestar){
                        resultado = num1 - num2;
                        mensaje = "La resta es: \n" + resultado;
                    }else if (idSeleccionado == R.id.rbMultiplicar){
                        resultado = num1 * num2;
                        mensaje = "La multiplicación es: \n" + resultado;
                    }else if (idSeleccionado == R.id.rbDividir){
                        if (num2 != 0) {
                            resultado = num1 / num2;
                            mensaje = "La división es: \n" + resultado;
                        } else {
                            Toast.makeText(getContext(), "No se puede dividir entre 0", Toast.LENGTH_SHORT).show();
                        }
                    }

                    tvResultado.setText(mensaje);

                } else {
                    tvResultado.setText("Introduce los números.");
                }



            }

        });

        return v;
    }

}