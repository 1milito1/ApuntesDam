package com.milito.tarea8;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.Fragment;

public class NavegadorFragment extends Fragment {

    private EditText etUrl;
    private Button btnIr;
    private WebView wvWeb;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_navegador, container, false);

        etUrl = v.findViewById(R.id.etUrl);
        btnIr = v.findViewById(R.id.btnIr);
        wvWeb = v.findViewById(R.id.wvWeb);

        wvWeb.setWebViewClient(new WebViewClient());
        wvWeb.getSettings().setJavaScriptEnabled(true);

        btnIr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = etUrl.getText().toString();
                wvWeb.loadUrl("https://" + url);
            }
        });

        return v;

    }



}
