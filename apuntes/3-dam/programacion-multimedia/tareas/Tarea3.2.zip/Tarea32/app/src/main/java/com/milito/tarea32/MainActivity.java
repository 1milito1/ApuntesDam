package com.milito.tarea32;

//Alumno: Emilio José García Esteban
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText etOp1;
    private EditText etOp2;
    private Button btnSumar;
    private Button btnRestar;
    private Button btnMultiplicar;
    private Button btnDividir;
    private TextView tvResultado;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etOp1 = findViewById(R.id.etOp1);
        etOp2 = findViewById(R.id.etOp2);
        btnSumar = findViewById(R.id.btnSumar);
        btnRestar = findViewById(R.id.btnRestar);
        btnMultiplicar = findViewById(R.id.btnMultiplicar);
        btnDividir = findViewById(R.id.btnDividir);
        tvResultado = findViewById(R.id.tvResultado);


        ManejarResultados resultados = new ManejarResultados();
        btnSumar.setOnClickListener(resultados);
        btnRestar.setOnClickListener(resultados);
        btnMultiplicar.setOnClickListener(resultados);
        btnDividir.setOnClickListener(resultados);


    }

    private class ManejarResultados implements View.OnClickListener {

        @Override
        public void onClick(View v) {
        if(etOp1.getText().toString().isEmpty() || etOp2.getText().toString().isEmpty()){
            Toast.makeText(MainActivity.this, "Ingrese los valores. Faltan datos.", Toast.LENGTH_SHORT).show();
            return;
        } else {
            try{
                double op1 = Double.parseDouble(etOp1.getText().toString());
                double op2 = Double.parseDouble(etOp2.getText().toString());
                double resultado = 0;
                String operacion ="";

                if(v.getId() == R.id.btnSumar){
                    resultado = op1 + op2;
                    operacion = "+";
                } else if(v.getId() == R.id.btnRestar){
                    resultado = op1 - op2;
                    operacion = "-";
                } else if(v.getId() == R.id.btnMultiplicar){
                    resultado = op1 * op2;
                    operacion = "*";
                } else if(v.getId() == R.id.btnDividir){
                    if(op2 == 0){
                        Toast.makeText(MainActivity.this, "No se puede dividir por cero.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    resultado = op1 / op2;
                    operacion = "/";
                }

                tvResultado.setText("Resultado: \n" + op1 + " " + operacion + " " + op2 + " = " + resultado);

        } catch (NumberFormatException e) {
                tvResultado.setText("Error: Tipo de dato incorrecto.");
            }

        }
        }
    }
}