package com.milito.tarea31;

//Alumno: Emilio José García Esteban

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText edNombre;
    private EditText edApellidos;
    private EditText edEmail;
    private EditText edTelefono;
    private Button btnMostrar;
    private TextView tvResultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        edNombre = findViewById(R.id.edNombre);
        edApellidos = findViewById(R.id.edApellidos);
        edEmail = findViewById(R.id.edEmail);
        edTelefono = findViewById(R.id.edTelefono);
        btnMostrar = findViewById(R.id.btnMostrar);
        tvResultado = findViewById(R.id.tvResultado);

        btnMostrar.setOnClickListener(v -> {
                String nombre = edNombre.getText().toString();
                String apellidos = edApellidos.getText().toString();
                String email = edEmail.getText().toString();
                String telefono = edTelefono.getText().toString();

                if(nombre.isEmpty() || apellidos.isEmpty() || email.isEmpty() || telefono.isEmpty()){
                    Toast.makeText(this, "Faltan datos por rellenar", Toast.LENGTH_SHORT).show();
                    tvResultado.setText("Rellena todos los campos.");
                } else {
                    tvResultado.setText("Nombre: " + nombre +
                            "\nApellidos: " + apellidos +
                            "\nEmail: " + email +
                            "\nTeléfono: " + telefono);
                }

        });

    }
}