package com.milito.tarea43;

//Alumno: Emilio José García Esteban

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private ListView lvCiudades;
    private TextView tvMensaje;
    private Map<String, String> mapaHabitantes;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);


        lvCiudades = findViewById(R.id.lvCiudades);
        tvMensaje = findViewById(R.id.tvMensaje);

        List<String>ciudades = Arrays.asList("Madrid", "Barcelona", "Valencia", "Sevilla");
        mapaHabitantes = new HashMap<>();
        mapaHabitantes.put("Madrid", "3.000.000");
        mapaHabitantes.put("Barcelona", "1.600.000");
        mapaHabitantes.put("Valencia", "786.000");
        mapaHabitantes.put("Sevilla", "695.000");


        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                ciudades

        );
        lvCiudades.setAdapter(adapter);

        lvCiudades.setOnItemClickListener(new manejadorCiudad());
    }

    private class manejadorCiudad implements AdapterView.OnItemClickListener{

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            String ciudadSeleccionada = (String) parent.getItemAtPosition(position);


            String habitantes = mapaHabitantes.get(ciudadSeleccionada);

            String mensaje = getString(R.string.mensaje, ciudadSeleccionada, habitantes);


            tvMensaje.setText(mensaje);


        }

    }
}