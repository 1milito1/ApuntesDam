package com.milito.tarea051;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText etNombre;
    private EditText etAltura;
    private EditText etPeso;
    private Button btnCalcular;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       etNombre = findViewById(R.id.etNombre);
       etAltura = findViewById(R.id.etAltura);
       etPeso = findViewById(R.id.etPeso);
       btnCalcular = findViewById(R.id.btnCalcular);


       btnCalcular.setOnClickListener(v->{
           String nombre = etNombre.getText().toString();
           Double altura =  Double.parseDouble(etAltura.getText().toString());
           Double peso = Double.parseDouble(etPeso.getText().toString());

           Intent intent = new Intent(this, ResultadoActivity.class);
           intent.putExtra("nombre", nombre);
           intent.putExtra("altura", altura);
           intent.putExtra("peso", peso);
           startActivity(intent);


       });
    }
}