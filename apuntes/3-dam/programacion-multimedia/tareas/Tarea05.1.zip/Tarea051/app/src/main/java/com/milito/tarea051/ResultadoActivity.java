package com.milito.tarea051;

//Alumno: Emilio José García Esteban
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ResultadoActivity extends AppCompatActivity {

    private TextView tvTitulo2;
    private TextView tvMensaje;
    private TextView tvRAltura;
    private TextView tvRPeso;
    private TextView tvIMC;
    private ImageView imageView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_resultado);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvTitulo2 = findViewById(R.id.tvTitulo2);
        tvMensaje = findViewById(R.id.tvMensaje);
        tvRAltura = findViewById(R.id.tvRAltura);
        tvRPeso = findViewById(R.id.tvRPeso);
        tvIMC = findViewById(R.id.tvIMC);
        imageView = findViewById(R.id.imageView);

        Intent intent = getIntent();
        String nombre = intent.getStringExtra("nombre");
        Double altura = intent.getDoubleExtra("altura", 0);
        Double peso = intent.getDoubleExtra("peso", 0);
        Double alturaMetros = altura / 100;
        Double imc = peso / (alturaMetros * alturaMetros);

        String tipo = tipoPeso(imc);


        String mensaje = String.format(getString(R.string.mensaje), nombre, tipo);
        tvMensaje.setText(mensaje);
        tvRAltura.setText("Altura: " + altura + " cm");
        tvRPeso.setText("Peso: " + peso + " kg");
        tvIMC.setText("Tu IMC es de: %.2f" + imc);


    }

    private String tipoPeso(Double imc){

        if(imc < 18.5){
            return "Bajo Peso";
        }else if(imc >= 18.5 && imc <= 24.9){
            return "Peso Normal";
        }else if(imc >= 25 && imc <= 29.9){
            return "Sobrepeso";
        }else{
            return "Obesidad";
        }
    }
}