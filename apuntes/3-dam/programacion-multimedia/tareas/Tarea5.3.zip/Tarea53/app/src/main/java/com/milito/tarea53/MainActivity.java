package com.milito.tarea53;


//Alumno: Emilio José García Esteban
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });

        ArrayList<Libro> listaLibros = new ArrayList<>();
        listaLibros.add(new Libro("Harry Potter y la piedra filosofal", "J.K: Rowling", R.drawable.harry1, 20.00));
        listaLibros.add(new Libro("Harry Potter y la cámara secreta", "J.K: Rowling", R.drawable.harry2, 18.00));
        listaLibros.add(new Libro("Harry Potter y el prisionero de Azkaban", "J.K: Rowling", R.drawable.harry3, 17.00));
        listaLibros.add(new Libro("Harry Potter y el cáliz de fuego", "J.K: Rowling", R.drawable.harry4, 15.00));
        listaLibros.add(new Libro("Harry Potter y la orden del fénix", "J.K: Rowling", R.drawable.harry5, 19.99));
        listaLibros.add(new Libro("Harry Potter y el misterio del príncipe", "J.K: Rowling", R.drawable.harry6, 25.00));
        listaLibros.add(new Libro("Harry Potter y las reliquias de la muerte", "J.K: Rowling", R.drawable.harry7, 30.50));

        LibroAdapter adapter = new LibroAdapter(this, listaLibros);
        ListView lv = findViewById(R.id.lvLibros);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Libro libroSeleccionado = listaLibros.get(position);

                String textoToast = "Libro: " + libroSeleccionado.getTitulo() + "\nImporte: " + libroSeleccionado.getPrecio();

                Toast.makeText(MainActivity.this, textoToast, Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(MainActivity.this, DetalleLibroActivity.class);
                intent.putExtra("titulo", libroSeleccionado.getTitulo());
                intent.putExtra("autor", libroSeleccionado.getAutor());
                intent.putExtra("imagen", libroSeleccionado.getImagen());
                intent.putExtra("precio", libroSeleccionado.getPrecio());

                startActivity(intent);
            }
        });


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_libros, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        int id = item.getItemId();

        if(id == R.id.itEmail){
            Toast.makeText(this, "Contacto: \nemilio.josegarciaesteban@gmail.com", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.itCerrar) {
            finishAffinity();
            return true;

        } else if (id == R.id.itAcerca) {
            Toast.makeText(this, "Autor: Emilio José García Esteban", Toast.LENGTH_SHORT).show();
            return true;

        }

        return super.onOptionsItemSelected(item);


    }
}