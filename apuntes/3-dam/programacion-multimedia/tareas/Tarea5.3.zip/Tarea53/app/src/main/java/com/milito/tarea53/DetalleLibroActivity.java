package com.milito.tarea53;

//Alumno: Emilio José García Esteban
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DetalleLibroActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_libro);

        String titulo = getIntent().getStringExtra("titulo");
        String autor = getIntent().getStringExtra("autor");
        Double precio = getIntent().getDoubleExtra("precio", 0.0);
        int imagen = getIntent().getIntExtra("imagen", 0);

        ImageView imgDetalle = findViewById(R.id.imgDetalle);
        TextView tvDetalleTitulo = findViewById(R.id.tvDetalleTitulo);
        TextView tvDetalleAutor = findViewById(R.id.tvDetalleAutor);
        TextView tvDetallePrecio = findViewById(R.id.tvDetallePrecio);

        imgDetalle.setImageResource(imagen);
        tvDetalleTitulo.setText(titulo);
        tvDetalleAutor.setText(autor);
        tvDetallePrecio.setText("Precio: " + precio + "€");


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_libros, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        int id = item.getItemId();

        if(id == R.id.itEmail){
            Toast.makeText(this, "Contacto: \nemilio.josegarciaesteban@gmail.com", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.itCerrar) {
            finishAffinity();
            return true;

        } else if (id == R.id.itAcerca) {
            Toast.makeText(this, "Autor: Emilio José García Esteban", Toast.LENGTH_SHORT).show();
            return true;

        }

        return super.onOptionsItemSelected(item);


    }
}
