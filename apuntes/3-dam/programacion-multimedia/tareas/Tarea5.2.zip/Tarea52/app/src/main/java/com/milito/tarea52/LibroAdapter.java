package com.milito.tarea52;

//Alumno: Emilio José García Esteban
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class LibroAdapter  extends ArrayAdapter<Libro> {

    public LibroAdapter(Context context, List<Libro> libros) {
        super(context, 0, libros);

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        Libro libro = getItem(position);

        if (convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_libro, parent, false);

        }
        ImageView img = convertView.findViewById(R.id.imgPortada);
        TextView titulo = convertView.findViewById(R.id.tvTitulo);
        TextView autor = convertView.findViewById(R.id.tvAutor);

        img.setImageResource(libro.getImagen());
        titulo.setText(libro.getTitulo());
        autor.setText(libro.getAutor());

        return convertView;
    }

}
