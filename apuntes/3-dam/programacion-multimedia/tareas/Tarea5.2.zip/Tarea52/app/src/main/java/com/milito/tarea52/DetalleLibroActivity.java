package com.milito.tarea52;

//Alumno: Emilio José García Esteban
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetalleLibroActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_libro);

        String titulo = getIntent().getStringExtra("titulo");
        String autor = getIntent().getStringExtra("autor");
        Double precio = getIntent().getDoubleExtra("precio", 0.0);
        int imagen = getIntent().getIntExtra("imagen", 0);

        ImageView imgDetalle = findViewById(R.id.imgDetalle);
        TextView tvDetalleTitulo = findViewById(R.id.tvDetalleTitulo);
        TextView tvDetalleAutor = findViewById(R.id.tvDetalleAutor);
        TextView tvDetallePrecio = findViewById(R.id.tvDetallePrecio);

        imgDetalle.setImageResource(imagen);
        tvDetalleTitulo.setText(titulo);
        tvDetalleAutor.setText(autor);
        tvDetallePrecio.setText("Precio: " + precio + "€");


    }
}
