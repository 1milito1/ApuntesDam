package com.milito.tarea52;

//Alumno: Emilio José García Esteban
public class Libro {
    private String titulo;
    private String autor;
    private int imagen;
    private Double precio;

    public Libro(String titulo, String autor, int imagen, Double precio) {
        this.titulo = titulo;
        this.autor = autor;
        this.imagen = imagen;
        this.precio = precio;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getImagen() {
        return imagen;
    }

    public void setImagen(int imagen) {
        this.imagen = imagen;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }


    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
}
