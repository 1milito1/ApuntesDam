package com.milito.tarea34;

// Alumno: Emilio José García Esteban
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private ImageView ivFoto;
    private Button btnCambiar;
    private CheckBox cbDesaBoton;
    private RadioGroup rgImagen;
    private RadioButton rbMostrar;
    private RadioButton rbOcultar;

    private boolean Imagen1 = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ivFoto = findViewById(R.id.ivFoto);
        btnCambiar = findViewById(R.id.btnCambiar);
        cbDesaBoton = findViewById(R.id.cbDesaBoton);
        rgImagen = findViewById(R.id.rgImagen);
        rbMostrar = findViewById(R.id.rbMostrar);
        rbOcultar = findViewById(R.id.rbOcultar);



        // Deshabilitar el botón al comenzar
        cbDesaBoton.setChecked(true);
        btnCambiar.setEnabled(!cbDesaBoton.isChecked());

        // Listener para el boton y cambiar entre las dos fotos
        btnCambiar.setOnClickListener(view -> {
                if (Imagen1) {
            ivFoto.setImageResource(R.drawable.foto2);

                }else {
            ivFoto.setImageResource(R.drawable.foto1);
        }

            Imagen1 = !Imagen1;
        });

        // listener para ver el estado del checkbox y habilitar o no el boton
        cbDesaBoton.setOnCheckedChangeListener((buttonView, isChecked) -> {

            if (isChecked) {
                btnCambiar.setEnabled(false);
                Toast.makeText(this, "Boton deshabilitado", Toast.LENGTH_SHORT).show();
            } else {
                btnCambiar.setEnabled(true);
                Toast.makeText(this, "Boton habilitado", Toast.LENGTH_SHORT).show();

            }
        });


        // Listener para la logica de los radio button para mostrar u ocultar la imagen.
        rgImagen.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbMostrar) {
                ivFoto.setVisibility(View.VISIBLE);
                Toast.makeText(this, "Imagen mostrada", Toast.LENGTH_SHORT).show();
            }else if (checkedId == R.id.rbOcultar) {
                ivFoto.setVisibility(View.INVISIBLE);
                Toast.makeText(this, "Imagen oculta", Toast.LENGTH_SHORT).show();
            }
        });
    }


}