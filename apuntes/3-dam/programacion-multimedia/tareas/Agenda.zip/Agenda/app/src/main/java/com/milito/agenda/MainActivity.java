package com.milito.agenda;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView lvContactos;
    private ArrayList<Contacto> listaContactos;
    private ContactoAdapter adaptador;
    private AdminSQLiteOpenHelper conSql;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        setTitle("Agenda de contactos de Emilio José García Esteban");
        setTitleColor(R.color.black);

        lvContactos = findViewById(R.id.lvContactos);
        conSql = new AdminSQLiteOpenHelper(this, "agenda", null, 1);

        cargarLista();

        lvContactos.setOnItemClickListener((adapterView, view, i, l) -> {
            Contacto contactoSeleccionado = listaContactos.get(i);
            Intent intent = new Intent(MainActivity.this, RegistroActivity.class);

            intent.putExtra("id",contactoSeleccionado.getId());
            intent.putExtra("nombre", contactoSeleccionado.getNombre());
            intent.putExtra("telefono", contactoSeleccionado.getTelefono());
            intent.putExtra("email", contactoSeleccionado.getEmail());

            startActivity(intent);
        });

        lvContactos.setOnItemLongClickListener((adapterView, view, i, l) -> {

            Contacto contatoBorrar = listaContactos.get(i);

            AlertDialog.Builder alerta = new AlertDialog.Builder(MainActivity.this);
            alerta.setTitle("Eliminar contacto");
            alerta.setMessage("Quieres borrar el contacto "+ contatoBorrar.getNombre() + "?");
            alerta.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    eliminar(contatoBorrar.getId());
                }
            });

            alerta.setNegativeButton("Cancelar", null);
            alerta.show();
            return true;
        });

    }

    @Override
    protected void onResume(){
        super.onResume();
        cargarLista();
    }
    private void cargarLista() {

        SQLiteDatabase db = conSql.getReadableDatabase();
        listaContactos = new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT * FROM contactos", null);

        if (cursor.moveToFirst()){
            do {
                listaContactos.add(new Contacto(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3)
                ));
            }while (cursor.moveToNext());

        }
        cursor.close();
        db.close();

        adaptador = new ContactoAdapter(this, listaContactos);
        lvContactos.setAdapter(adaptador);
    }

    private void eliminar(int id){

        SQLiteDatabase db = conSql.getWritableDatabase();
        int cantidad = db.delete("contactos", "id=" + id, null);
        db.close();

        if (cantidad >0){
            Toast.makeText(this, "Contacto eliminado correctamente", Toast.LENGTH_SHORT).show();
            cargarLista();
        }

    }

    @Override
    public boolean onCreateOptionsMenu (Menu menu){
        MenuItem item = menu.add(Menu.NONE, 1, Menu.NONE, "Añadir");
        item.setIcon(android.R.drawable.ic_input_add);
        item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item) {
        if (item.getItemId() ==1){
            Intent intent = new Intent(this, RegistroActivity.class);
            startActivityForResult(intent,100);
            return true;
        }
        return super.onOptionsItemSelected(item);


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, requestCode, data);
        if(resultCode == RESULT_OK){
            cargarLista();
        }
    }

}