package com.milito.tarea9;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText etContacto, etMensaje;
    Button btnContacto, btnEnviar;
    public static final int PERMISSION_REQUEST_CODE = 123;
    public static final int CONTACT_PICK_CODE = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        etContacto = findViewById(R.id.etContacto);
        etMensaje = findViewById(R.id.etMensaje);
        btnContacto = findViewById(R.id.btnContacto);
        btnEnviar = findViewById(R.id.btnEnviar);


        solicitarPermisos();

        btnEnviar.setOnClickListener(v -> enviarSms());
        btnContacto.setOnClickListener(v -> abrirAgenda());

    }


    public void solicitarPermisos() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS}, PERMISSION_REQUEST_CODE);

        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        solicitarPermisos();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CONTACT_PICK_CODE && resultCode == RESULT_OK) {
            Uri contactUri = data.getData();

            Cursor cursor = getContentResolver().query(contactUri, null, null, null, null);

            if (cursor != null && cursor.moveToFirst()) {

                int numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);


                String numero = cursor.getString(numberIndex);

                etContacto.setText(numero);
                cursor.close();
            }
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_CODE) {
            for (int result : grantResults) {
                if (result == PackageManager.PERMISSION_DENIED) {
                    Toast.makeText(this, "Permisos necesarios para la app. Cerrando...", Toast.LENGTH_LONG).show();
                    finish();
                    break;
                }
            }
        }
    }
    private void abrirAgenda() {

        Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(intent, CONTACT_PICK_CODE);
    }

    private void enviarSms() {

        String numero = etContacto.getText().toString();
        String mensaje = etMensaje.getText().toString();
        
        if (numero.isEmpty() || mensaje.isEmpty()) {
            Toast.makeText(this, "Por favor, ingrese un número de teléfono y un mensaje", Toast.LENGTH_SHORT).show();

        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                android.telephony.SmsManager smsManager = android.telephony.SmsManager.getDefault();
                smsManager.sendTextMessage(numero, null, mensaje, null, null);
                Toast.makeText(this, "Mensaje enviado", Toast.LENGTH_SHORT).show();
                etContacto.setText("");
                etMensaje.setText("");
            } catch (Exception e){
                Toast.makeText(this, "Error al enviar el mensaje", Toast.LENGTH_SHORT).show();
            }

            
        }else {
            solicitarPermisos();
        }


    }



}