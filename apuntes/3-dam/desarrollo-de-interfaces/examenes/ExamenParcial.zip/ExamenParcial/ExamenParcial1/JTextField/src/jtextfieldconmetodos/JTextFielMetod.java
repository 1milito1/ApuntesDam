package jtextfieldconmetodos;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JTextField;
import java.awt.*;

/**
 * JTextField personalizado que reemplaza palabras espec�ficas al escribir.
 */
public class JTextFielMetod extends JTextField {

    private String palabraSecreta =""; // Palabra a busca

    /**
     * Constructor predeterminado.
     */
    public JTextFielMetod() {
        // Agregar un KeyListener para detectar eventos de teclado
        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                // Verificar si la palabra secreta est� presente y reemplazarla
                String mensaje = "La palabra secreta no se muestra";
                palabraSecreta += getText();
                setText(mensaje);
                setForeground(Color.red);
                palabraSecreta = palabraSecreta.replace(mensaje,"");
            }
        });
        
        
    }

    /**
     * Se devuelve la palbra secreta
     * @return tipo String
     */
    public String getPalabraSecreta(){
            return palabraSecreta;
     }
    
    /**
     * Sobrescribir el m�todo addKeyListener para evitar problemas con listeners
     * adicionales.
     */
    @Override
    public synchronized void addKeyListener(java.awt.event.KeyListener l) {
        super.addKeyListener(l);
    }
}