/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemasnumeracio;

/**
 *
 * @author dmiap
 */
public class SistemasNumeracio {

    /**
     * @param args the command line arguments
     */
    public static void mostrar() {
        // Ejemplos de uso (puedes eliminarlos si no quieres interacción por consola)
        String binario = "1011";
        int decimal = 13;

        // Convertir binario a decimal
        int resultadoDecimal = Conversor.aDecimal(binario);
        System.out.println("Binario " + binario + " a decimal: " + resultadoDecimal);

        // Convertir decimal a binario
        String resultadoBinario = Conversor.aBinario(decimal);
        System.out.println("Decimal " + decimal + " a binario: " + resultadoBinario);
    }
    
}
