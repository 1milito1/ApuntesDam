/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemasnumeracio;

/**
 *
 * @author dmiap
 */
public class Conversor {

    // Convierte un número binario (String) a decimal (int)
    public static int aDecimal(String binario) throws NumberFormatException {
        return Integer.parseInt(binario, 2);
    }

    // Convierte un número decimal (int) a binario (String)
    public static String aBinario(int decimal) {
        return Integer.toBinaryString(decimal);
    }
}
