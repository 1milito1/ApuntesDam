/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jpanelreutilizable;

import java.awt.AlphaComposite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.Serializable;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 *
 * @author milio
 */
public class JPanelReutilizable extends JPanel implements Serializable{
    
    private ImagenSelector imagenFondo; 
    private boolean ratonPresionado = false;
    private Point puntoPresion;
    private ArrastreListener arrastreListener;
    
    public JPanelReutilizable(){
    
        //Escucha los clicks de mouse y si se ha desplazado en este caso en vertical (y) y 50 px
        this.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseReleased(MouseEvent e) {
                if (ratonPresionado){
                    Point posicionActual = e.getPoint();
                    if(Math.abs(puntoPresion.y - posicionActual.y)> 50){
                       if(arrastreListener!=null){
                            arrastreListener.arrastre();
                       }
                    }
                }
                ratonPresionado= false;
            }

            @Override
            public void mousePressed(MouseEvent e) {
                
                ratonPresionado = true;
                puntoPresion = e.getPoint();
            }
            
        }
        
        );
    }
    
    public void addArrastreListener(ArrastreListener arrastreListener){
        this.arrastreListener = arrastreListener;
    }

    public void removeArrastreListener(){
        this.arrastreListener = null;
    }
    
    public ImagenSelector getImagenFondo() {
        return imagenFondo;
    }

    public void setImagenFondo(ImagenSelector imagenFondo) {
        this.imagenFondo = imagenFondo;
        repaint();
    }



    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); 
        if(imagenFondo!=null)
            if(imagenFondo.getRutaImagenInicial()!= null && imagenFondo.getRutaImagenInicial().exists()){
                ImageIcon imageIcon = new ImageIcon(imagenFondo.getRutaImagenInicial().getAbsolutePath());
                Graphics2D g2d = (Graphics2D)g;
                g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, imagenFondo.getOpacidadInicial()));
                //g.drawImage(imageIcon.getImage(), 0, 0, null); //<--- Forma del video 
                
                //Forma para que la imagen se adapte al panelReutilizable
                g.drawImage(
                    imageIcon.getImage(), 
                    0, 0, 
                    getWidth(),  
                    getHeight(), 
                    this);
                g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1));//Se resetea la opacidad 

            }
         }
    }


    
    
    

