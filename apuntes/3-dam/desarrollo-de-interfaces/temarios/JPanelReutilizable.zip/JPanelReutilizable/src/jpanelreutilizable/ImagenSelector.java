/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jpanelreutilizable;

import java.io.File;
import java.io.Serializable;

/**
 *
 * @author milio
 */
public class ImagenSelector implements Serializable{
    
    //Variables
    private File rutaImagenInicial;
    private File rutaImagenFinal;
    private float opacidadInicial;
    private float opacidadFinal;

    //Constructor
    public ImagenSelector(File rutaImagenInicial, File rutaImagenFinal, float opacidadInicial, float opacidadFinal) {
        this.rutaImagenInicial = rutaImagenInicial;
        this.rutaImagenFinal = rutaImagenFinal;
        this.opacidadInicial = opacidadInicial;
        this.opacidadFinal = opacidadFinal;
    }

    //Getters y Setters
    public File getRutaImagenInicial() {
        return rutaImagenInicial;
    }

    public void setRutaImagenInicial(File rutaImagenInicial) {
        this.rutaImagenInicial = rutaImagenInicial;
    }

    public File getRutaImagenFinal() {
        return rutaImagenFinal;
    }

    public void setRutaImagenFinal(File rutaImagenFinal) {
        this.rutaImagenFinal = rutaImagenFinal;
    }

    public float getOpacidadInicial() {
        return opacidadInicial;
    }

    public void setOpacidadInicial(float opacidadInicial) {
        this.opacidadInicial = opacidadInicial;
    }

    public float getOpacidadFinal() {
        return opacidadFinal;
    }

    public void setOpacidadFinal(float opacidadFinal) {
        this.opacidadFinal = opacidadFinal;
    }
    
   
    
}
