/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jpanelreutilizable;

import java.awt.Component;
import java.beans.PropertyEditorSupport;

/**
 *
 * @author milio
 */
public class ImagenSelectorPropertyEditorSupport extends PropertyEditorSupport{

    private ImagenSelectorPanel imagenSelectorPanel = new ImagenSelectorPanel();
    @Override
    public boolean supportsCustomEditor() {
        return true;
    }

    @Override
    public Component getCustomEditor() {
        return imagenSelectorPanel;
    }

    @Override
    public String getJavaInitializationString() {
        /*ImagenSelector imagenFondo = imagenSelectorPanel.getSelectedValue();
        return "new jpanelreutilizable.ImagenSelector(" + "new java.io.File(\""+ imagenFondo.getRutaImagen().getAbsolutePath()+"\") , " + imagenFondo.getOpacidad()+")";*/
    /*Dado que la manera propuesta por el video (lo anterior) no me funciona dando error al esperar File y float y solo recibir File
      he descubierto que el error lo producian las barras \ en la ruta de los archivos, asi que procedo a cambiar esas \ simples
      que dan error por barras \\  que no lo dan para poder acceder a la foto para poner de fondo sin errores*/
    
    ImagenSelector imagenFondo = imagenSelectorPanel.getSelectedValue();
    
    // 1. Obtenenemos las rutas absolutas del archivo
    String rutaImagenInicial= imagenFondo.getRutaImagenInicial().getAbsolutePath();
    String rutaImagenFinal= imagenFondo.getRutaImagenFinal().getAbsolutePath();
    
    // 2. Formateo esa ruta para que sea válida en Java
    String rutaValidaInicial = rutaImagenInicial.replace("\\", "\\\\");
    String rutaValidaFinal = rutaImagenFinal.replace("\\", "\\\\");
        System.out.println(rutaValidaInicial);
    
    // 3. Generar la cadena de inicialización
    return "new jpanelreutilizable.ImagenSelector(" 
           + "new java.io.File(\"" + rutaValidaInicial + "\"), " 
           + "new java.io.File(\"" + rutaValidaFinal + "\"), "
           + imagenFondo.getOpacidadInicial() + "f,"
           + imagenFondo.getOpacidadFinal() + "f)";
    
    }

    @Override
    public Object getValue() {
        return imagenSelectorPanel.getSelectedValue();
    }
    
    
}
