/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea05listadeusuarios;

/**
 *
 * @author milio
 */
public class Alumno {
    String nif;
    String nombre;
    String apellido1;
    String apellido2;
    String usuario;

    public Alumno(String nif, String nombre, String apellido1, String apellido2, String usuario) {
        this.nif = nif;
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.usuario = usuario;
    }

    public String getNif() {
        return nif;
    }

    public void setNif(String nif) {
        this.nif = nif;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido1() {
        return apellido1;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    @Override
    public String toString() {
        return "Alumno{" + "nif=" + nif + ", nombre=" + nombre + ", apellido1=" + apellido1 + ", apellido2=" + apellido2 + ", usuario=" + usuario + '}';
    }
    
   public void crearUsuario() {
        try {
            usuario = "";
            usuario += nombre.charAt(0);
            usuario += apellido1.charAt(0);
            usuario += apellido2.charAt(0);
        } catch (StringIndexOutOfBoundsException e) {
            System.out.println("Error: Nombre, apellido 1 o apellido 2 no tiene longitud suficiente para crear un usuario.");
        }
    }
}

