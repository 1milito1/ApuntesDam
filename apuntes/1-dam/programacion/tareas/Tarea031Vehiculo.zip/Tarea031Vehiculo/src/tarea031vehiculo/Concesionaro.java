/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea031vehiculo;

/**
 *
 * @author milio
 */
public class Concesionaro {
    public static void  main(String[] args) throws Exception{
    //Creación de objeto coche con parámetros
        Vehiculo coche1 = new Vehiculo("1234ABC", "Toyota", 20000);
    //Creación de objeto moto sin parámetros
        Vehiculo moto1 = new Vehiculo();
    
    //Parámetros de objeto moto
        try {
            moto1.setMatricula("7894CDE");
            moto1.setMarca("Yamaha");
            moto1.setPrecioCompra(15000);
        }
        catch(Exception e) {
            System.out.println(e.getMessage());
        }
        
    //Impresión por pantalla de ambos objetos    
        System.out.println("Coche 1: " + coche1);
        System.out.println("Moto 1: " + moto1);

    //calculo e imprsion de pvp
        double pvpCoche1 = coche1.pvp(20);
        double pvpMoto1 = moto1.pvp(30);
        
        System.out.println("El pvp del coche 1 es: " + pvpCoche1);
        System.out.println("El pvp de la moto 1 es: " + pvpMoto1);
        
    //Impresión por pantalla de ambos objetos coche con getter y moto con toString    
        System.out.println("Coche 1: ");
        System.out.println("Matricula: " + coche1.getMatricula());
        System.out.println("Marca: " + coche1.getMarca());
        System.out.println("Precio Compra: " + coche1.getPrecioCompra());
        System.out.println("Coche 1 pvp: " + coche1.pvp(20));

        System.out.println("Moto 1: " + moto1.toString());
        System.out.println("Moto 1 pvp: " + moto1.pvp(30));
  
    }
    
}

/*He dejado los dos métodos de impresion de datos por pantalla 
para que se viera el desarrollo del ejercicio, si solo se quisiera la
parte del ejercicio 4 habria que suprimir la parte de codigo con los
comentarios impresion por pantalla de ambos objetos y calculo e impresion 
de pvp*/