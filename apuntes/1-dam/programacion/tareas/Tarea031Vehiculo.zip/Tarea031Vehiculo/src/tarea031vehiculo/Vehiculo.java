/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea031vehiculo;

/**
 *
 * @author milio
 */
//Atributos clas Vehiculo
public final class Vehiculo {
    private String matricula;
    private String marca;
    private double precioCompra;
    
 //Metodo de la clase vehiculo constructor sin parámetros
    public Vehiculo(){
        this.matricula = "";
        this.marca = "";
        this.precioCompra = 0.0;
    }
    
 //Métodos clase vehiculo constructor con parámetros  
    public Vehiculo(String matricula, String marca, double precioCompra){
        this.setMatricula (matricula);
        this.setMarca(marca);
        this.setPrecioCompra(precioCompra);
    }

    //Métodos setters y getters 

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public double getPrecioCompra() {
        return precioCompra;
    }

    public void setPrecioCompra(double precioCompra) {
        this.precioCompra = precioCompra;
    }
    
    
    //Método toString
    @Override
    public String toString() {
        return "Vehiculo{" +
                "matricula='" + matricula + '\'' +
                ", marca='" + marca + '\'' +
                ", precioCompra=" + precioCompra +
                '}';
    }
    
    //Método pvp
    public double pvp(int beneficio) throws Exception{
        if(beneficio < 0 || beneficio >100){
            throw new Exception ("El beneficio debe estar entre 0 y 100");
        }
        return precioCompra + ((precioCompra * beneficio) / 100);
    }
}
