/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea04ejercicio01piramide;

import java.util.Scanner;

/**
 *
 * @author milio
 */
public class Tarea04Ejercicio01Piramide {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //Delaración de variable para la entra de número
        System.out.print("Introduzca el número de alturas: ");
        int numAltura = scanner.nextInt();
        scanner.close();
        
        System.out.println();
        for (int altura = 1; altura <= numAltura; altura ++){
            //Espacios en blanco para hacer forma de pirámide
            for (int blancos = 1; blancos<=numAltura-altura; blancos++){
                System.out.print(" ");
            }
            //Asteriscos
            for (int asteriscos=1; asteriscos <=(altura*2)-1; asteriscos++){
                System.out.print("*");
            }
            //Lo imprime todo
            System.out.println();
        }
        
    }
    
}
