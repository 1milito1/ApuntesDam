/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea04ejercicio03decirnota;

import java.util.Scanner;

/**
 *
 * @author milio
 */
public class Tarea04Ejercicio03DecirNota {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Introduzca una nota numérica: ");
        double nota = scanner.nextDouble();
        
        int intNota = (int) nota;
        double decimalNota = nota - intNota;
        
        String textNota = "";
        switch (intNota){
            case 0:
                textNota = "Cero";
                break;
            case 1:
                textNota = "Uno";
                break;
            case 2:
                textNota = "Dos";
                break;
            case 3:
                textNota = "Tres";
                break;
            case 4:
                textNota = "Cuatro";
                break;
            case 5:
                textNota = "Cinco";
                break;
            case 6:
                textNota = "Seis";
                break;
            case 7:
                textNota = "Siete";
                break;
            case 8:
                textNota = "Ocho";
                break;
            case 9:
                textNota = "Nueve";
                break;
            case 10:
                textNota = "Diez";
                break;
            default:
                textNota = "Nota inválida";                
                
        }
        String decimalTexto = "";
        if (decimalNota >0){
            int decimalInt = (int) (decimalNota * 10);
            String decimalString = "";
            switch (decimalInt){
                case 0:
                    decimalString = "Cero";
                    break;
                case 1:
                    decimalString = "Uno";
                    break;
                case 2:
                    decimalString = "Dos";
                    break;
                case 3:
                    decimalString = "Tres";
                    break;
                case 4:
                    decimalString = "Cuatro";
                    break;
                case 5:
                    decimalString = "Cinco";
                    break;
                case 6:
                    decimalString = "Seis";
                    break;
                case 7:
                    decimalString = "Siete";
                    break;
                case 8:
                    decimalString = "Ocho";
                    break;
                case 9:
                    decimalString = "Nueve";
                    break;
                default:
                    decimalString = "decimal inválido";                    
            }
            decimalTexto = " con " + decimalString;        }
    
    if (textNota.equals("nota inválida")){
        System.out.println(textNota);
    }else{
    System.out.println(textNota + decimalTexto);
        }
    
    }
}