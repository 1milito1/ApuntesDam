/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplicacion_movil;

/**
 *
 * @author milio
 */
public class movil {
    
    private long numTelefono;
    private long IMEI;
    private String marca;
    private So sistemaOperativo;
    private Dim dimensiones;
    private Cam camaraFrontal;
    private Cam camaraTrasera;

    public movil(long numTelefono, long IMEI, String marca, So sistemaOperativo, Dim dimensiones, Cam camaraFrontal, Cam camaraTrasera) {
        this.numTelefono = numTelefono;
        this.IMEI = IMEI;
        this.marca = marca;
        this.sistemaOperativo = sistemaOperativo;
        this.dimensiones = dimensiones;
        this.camaraFrontal = camaraFrontal;
        this.camaraTrasera = camaraTrasera;
    }

    public long getNumTelefono() {
        return numTelefono;
    }

    public void setNumTelefono(long numTelefono) {
        this.numTelefono = numTelefono;
    }

    public long getIMEI() {
        return IMEI;
    }

    public void setIMEI(long IMEI) {
        this.IMEI = IMEI;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public So getSistemaOperativo() {
        return sistemaOperativo;
    }

    public void setSistemaOperativo(So sistemaOperativo) {
        this.sistemaOperativo = sistemaOperativo;
    }

    public Dim getDimensiones() {
        return dimensiones;
    }

    public void setDimensiones(Dim dimensiones) {
        this.dimensiones = dimensiones;
    }

    public Cam getCamaraFrontal() {
        return camaraFrontal;
    }

    public void setCamaraFrontal(Cam camaraFrontal) {
        this.camaraFrontal = camaraFrontal;
    }

    public Cam getCamaraTrasera() {
        return camaraTrasera;
    }

    public void setCamaraTrasera(Cam camaraTrasera) {
        this.camaraTrasera = camaraTrasera;
    }

    @Override
    public String toString() {
        return "movil{" + "numTelefono=" + numTelefono + ", IMEI=" + IMEI + ", marca=" + marca + ", sistemaOperativo=" + sistemaOperativo + ", dimensiones=" + dimensiones + ", camaraFrontal=" + camaraFrontal + ", camaraTrasera=" + camaraTrasera + '}';
    }
    
    
}
