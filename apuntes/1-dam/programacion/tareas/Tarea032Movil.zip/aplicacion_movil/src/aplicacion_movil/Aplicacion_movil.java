/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplicacion_movil;

import java.util.Scanner;

/**
 *
 * @author milio
 */
public class Aplicacion_movil {

    
    public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      
      System.out.print ("Introdduce el número de teléfono: ");
      long numTelefono = scanner.nextLong();
      
      System.out.print ("Introduce el IMEI: ");
      long IMEI = scanner.nextLong();
      
      scanner.nextLine();
      
      System.out.print("Introduce la marca: ");
      String marca = scanner.nextLine();
      
      System.out.print("Introduce el sistema operativo: ");
      String tipoSO = scanner.nextLine();
      
      System.out.print("Introduce la versión del sistema operativo: ");
      int versionSO = scanner.nextInt();
      
      So sistemaOperativo = new So(tipoSO, versionSO);
      
      System.out.print("Introduce el peso: ");
      int peso = scanner.nextInt();
      
      System.out.print("Introduce el largo: ");
      int largo = scanner.nextInt();
      
      System.out.print("Introduce el ancho: ");
      int ancho = scanner.nextInt();
      
      System.out.print("Introduce el alto: ");
      int alto = scanner.nextInt();
      
      Dim dimensiones = new Dim(peso, largo, ancho, alto);
      
      System.out.print("Introduce la resolución de la cámara frontal: ");
      int resolucionCamaraFrontal = scanner.nextInt();
      
      System.out.print("Introduce el número de cámaras frontales: ");
      int numCamarasFrontal = scanner.nextInt();
      
      System.out.print("¿Tiene estabilizador de imagen? ");
      boolean estabilizadorCamaraFrontal = scanner.nextBoolean();
      
      Cam camaraFrontal = new Cam(resolucionCamaraFrontal, numCamarasFrontal, estabilizadorCamaraFrontal);
      
      System.out.print("Introduce la resolución de la cámara trasera: ");
      int resolucionCamaraTrasera = scanner.nextInt();
      
      System.out.print("Introduce el número de cámaras traseras: ");
      int numCamarasTrasera = scanner.nextInt();
      
      System.out.print("¿Tiene estabilizador de imagen la cámara?");
      boolean estabilizadorCamaraTrasera = scanner.nextBoolean();
      
      Cam camaraTrasera = new Cam(resolucionCamaraTrasera, numCamarasTrasera, estabilizadorCamaraTrasera);
      
      movil movil1 = new movil(numTelefono, IMEI, marca, sistemaOperativo, dimensiones, camaraFrontal, camaraTrasera);
      
      System.out.print(movil1);
    }
    
}
