/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplicacion_movil;

/**
 *
 * @author milio
 */
public class Cam {
    private int resolucion;
    private int numCamaras;
    private boolean estabilizador;

    public Cam(int resolucion, int numCamaras, boolean estabilizador) {
        this.resolucion = resolucion;
        this.numCamaras = numCamaras;
        this.estabilizador = estabilizador;
    }

    public int getResolucion() {
        return resolucion;
    }

    public void setResolucion(int resolucion) {
        this.resolucion = resolucion;
    }

    public int getNumCamaras() {
        return numCamaras;
    }

    public void setNumCamaras(int numCamaras) {
        this.numCamaras = numCamaras;
    }

    public boolean isEstabilizador() {
        return estabilizador;
    }

    public void setEstabilizador(boolean estabilizador) {
        this.estabilizador = estabilizador;
    }

    @Override
    public String toString() {
        return "Cam{" + "resolucion=" + resolucion + ", numCamaras=" + numCamaras + ", estabilizador=" + estabilizador + '}';
    }
    
    
}
