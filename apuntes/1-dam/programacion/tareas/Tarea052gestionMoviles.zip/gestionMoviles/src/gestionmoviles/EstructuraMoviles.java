/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionmoviles;

import java.util.ArrayList;
import java.util.HashMap;

public class EstructuraMoviles {
    private HashMap<String, Movil> moviles;

    public EstructuraMoviles() {
        moviles = new HashMap<>();
    }

    public void añadirMovil(Movil movil) {
        moviles.put(movil.getNumTelefono(), movil);
    }

    public Movil buscarMovil(String numTelefono) {
        return moviles.get(numTelefono);
    }

    public void hacerLlamada(String numTelefono, int numDestino) {
        Movil movil = moviles.get(numTelefono);
        if (movil != null) {
            movil.realizarLlamada(numDestino);
        }
    }

    public ArrayList<Integer> verLlamadas(String numTelefono) {
        Movil movil = moviles.get(numTelefono);
        if (movil != null) {
            return movil.getLlamadas();
        }
        return null;
    }

    public HashMap<String, Movil> getMoviles() {
        return moviles;
    }

    public void setMoviles(HashMap<String, Movil> moviles) {
        this.moviles = moviles;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Movil movil : moviles.values()) {
            sb.append(movil.toString()).append("\n");
        }
        return sb.toString();
    }
}