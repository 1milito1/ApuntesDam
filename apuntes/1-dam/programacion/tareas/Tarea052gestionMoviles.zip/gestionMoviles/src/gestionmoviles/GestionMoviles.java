/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionmoviles;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class GestionMoviles {
    private EstructuraMoviles estructuraMoviles;
    private Scanner scanner;

    public GestionMoviles() {
        estructuraMoviles = new EstructuraMoviles();
        scanner = new Scanner(System.in);
    }

    public static void main(String[] args) {
        GestionMoviles gestionMoviles = new GestionMoviles();
        int opcion = 0;
        while (opcion != 6) {
            System.out.println("1. Alta Movil");
            System.out.println("2. Mostrar Movil");
            System.out.println("3. Hacer llamada");
            System.out.println("4. Ver llamadas");
            System.out.println("5. Listado");
            System.out.println("6. Salir");
            System.out.print("Introduzca una opción: ");
            opcion = gestionMoviles.scanner.nextInt();
            System.out.println();
            switch (opcion) {
                case 1:
                    gestionMoviles.altaMovil();
                    break;
                case 2:
                    gestionMoviles.mostrarMovil();
                    break;
                case 3:
                    gestionMoviles.hacerLlamada();
                    break;
                case 4:
                    gestionMoviles.verLlamadas();
                    break;
                case 5:
                    gestionMoviles.listadoMoviles();
                    break;
                case 6:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
            System.out.println();
        }
    }

    public void altaMovil() {
        System.out.print("Introduzca el número de teléfono: ");
        String numTelefono = scanner.next();
        System.out.print("Introduzca el IMEI: ");
        String IMEI = scanner.next();
        System.out.print("Introduzca el modelo: ");
        String modelo = scanner.next();
        Movil movil = new Movil(numTelefono, IMEI, modelo);
        estructuraMoviles.añadirMovil(movil);
    }

    public void mostrarMovil() {
        System.out.print("Introduzca el número de teléfono: ");
        String numTelefono = scanner.next();
        Movil movil = estructuraMoviles.buscarMovil(numTelefono);
        if (movil != null) {
            System.out.println(movil.toString());
        } else {
            System.out.println("No se ha encontrado ningún móvil con ese número de teléfono.");
        }
    }

        public void hacerLlamada() {
        System.out.print("Introduzca el número de teléfono que va a realizar la llamada: ");
        String numTelefono = scanner.next();
        System.out.print("Introduzca el número de teléfono al que quiere llamar: ");
        int numDestino = scanner.nextInt();
        Movil movil = estructuraMoviles.buscarMovil(numTelefono);
        if (movil != null) {
            movil.realizarLlamada(numDestino);
            System.out.println("Llamando a" + numDestino);
        } else {
            System.out.println("No se ha encontrado ningún móvil con ese número de teléfono.");
        }
    }

    public void verLlamadas() {
        System.out.print("Introduzca el número de teléfono: ");
        String numTelefono = scanner.next();
        ArrayList<Integer> llamadas = estructuraMoviles.verLlamadas(numTelefono);
        if (llamadas != null) {
            System.out.println("Llamadas realizadas por el móvil con número " + numTelefono + ":");
            for (int llamada : llamadas) {
                System.out.println(llamada);
            }
        } else {
            System.out.println("No se ha encontrado ningún móvil con ese número de teléfono.");
        }
    }

    public void listadoMoviles() {
        ArrayList<Movil> moviles = new ArrayList<>(estructuraMoviles.getMoviles().values());
        Collections.sort(moviles, Comparator.comparing(Movil::getNumTelefono));
        System.out.println("Listado de móviles:");
        for (Movil movil : moviles) {
            System.out.println(movil.toString());
        }
    }
}