/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionmoviles;

import java.util.ArrayList;
import java.util.Collections;

public class Movil {
    private String numTelefono;
    private String IMEI;
    private String modelo;
    private ArrayList<Integer> llamadas;

    public Movil(String numTelefono, String IMEI, String modelo) {
        this.numTelefono = numTelefono;
        this.IMEI = IMEI;
        this.modelo = modelo;
        this.llamadas = new ArrayList<>();
    }

    public String getNumTelefono() {
        return numTelefono;
    }

    public void setNumTelefono(String numTelefono) {
        this.numTelefono = numTelefono;
    }

    public String getIMEI() {
        return IMEI;
    }

    public void setIMEI(String IMEI) {
        this.IMEI = IMEI;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public ArrayList<Integer> getLlamadas() {
        return llamadas;
    }

    public void setLlamadas(ArrayList<Integer> llamadas) {
        this.llamadas = llamadas;
    }

    public void realizarLlamada(int numero) {
        llamadas.add(numero);
        Collections.sort(llamadas, Collections.reverseOrder());
    }

    @Override
    public String toString() {
        return "Movil{" +
                "numTelefono='" + numTelefono + '\'' +
                ", IMEI='" + IMEI + '\'' +
                ", modelo='" + modelo + '\'' +
                ", llamadas=" + llamadas +
                '}';
    }
}