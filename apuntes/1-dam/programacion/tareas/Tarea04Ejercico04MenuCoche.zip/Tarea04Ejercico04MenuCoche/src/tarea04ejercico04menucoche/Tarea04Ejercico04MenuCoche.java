/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea04ejercico04menucoche;

import java.util.Scanner;

/**
 *
 * @author milio
 */
public class Tarea04Ejercico04MenuCoche {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
        Scanner scanner = new Scanner(System.in);
        Coche coche = null;
        int opcion;
        boolean salir = false;
        
        while (!salir){
            System.out.println("\n Menú de opciones:");
            System.out.println("1. Generar coche");
            System.out.println("2. Cambiar color");
            System.out.println("3. Mostrar datos del coche");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            
            try{
                opcion = scanner.nextInt();
                switch (opcion){
                    case 1:
                        coche = new Coche("Seat", "Leon", "Rojo", 5);
                        System.out.println("Coche generado correctamente");
                        break;
                    case 2:
                        if (coche == null){
                            System.out.println("No hay ningún coche guardado");
                        }else{
                            System.out.println("Introduzca el nuevo Color: ");
                            String nuevoColor = scanner.next();
                            coche.setColor(nuevoColor);
                            System.out.println("Color cambiado con éxito");
                        }
                        break;
                    case 3:
                        if (coche==null){
                            System.out.println("No hay ningún coche guaardado");
                        }else{
                            System.out.println(coche.toString());
                        }
                        break;
                    case 4:
                        salir = true;
                        break;
                    default:
                        System.out.println("Opción no válida.");                        
                }
            }catch (Exception e){
                System.out.println("Error: " + e.getMessage());
                break;
            }
        }
            scanner.close();
    }
}
    
