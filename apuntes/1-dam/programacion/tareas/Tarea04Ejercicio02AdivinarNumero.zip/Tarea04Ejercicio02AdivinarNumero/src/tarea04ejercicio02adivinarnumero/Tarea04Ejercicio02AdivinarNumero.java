/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarea04ejercicio02adivinarnumero;

import java.util.Scanner;

/**
 *
 * @author milio
 */
public class Tarea04Ejercicio02AdivinarNumero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
       int numSecreto=7;
       int intentos=0;
       boolean continuar=true;
       
       while (continuar){
           System.out.print("Introduzca un número entre el 1 y el 10: ");
       int numIntroducido = scanner.nextInt();
       intentos++;
       
       if(numIntroducido==numSecreto){
           System.out.println("¡Felicidades! has adivinado el número secreo");
           continuar = false;
                   
       }else if (numIntroducido < numSecreto){
        System.out.println("El número es menor que el secreto");
        
       }else{
           System.out.println("El número es mayor que el secreto");
        }
       }
       System.out.println("Has realizado " +intentos + " intentos");
    }
    
}
