/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prácticaunidad3;

import junit.framework.TestCase;

/**
 *
 * @author milio
 */
public class CCuentaTest extends TestCase {
    
    public CCuentaTest(String testName) {
        super(testName);
    }

    /**
     * Test of asignarNombre method, of class CCuenta.
     */
    public void testAsignarNombre() {
        System.out.println("asignarNombre");
        String nom = "";
        CCuenta instance = new CCuenta();
        instance.asignarNombre(nom);
        
    }

    /**
     * Test of obtenerNombre method, of class CCuenta.
     */
    public void testObtenerNombre() {
        System.out.println("obtenerNombre");
        CCuenta instance = new CCuenta();
        String expResult = "";
        String result = instance.obtenerNombre();
        assertEquals(expResult, result, null);
        
    }

    /**
     * Test of estado method, of class CCuenta.
     */
    public void testEstado() {
        System.out.println("estado");
        CCuenta instance = new CCuenta();
        double expResult = 0.0;
        double result = instance.estado();
        assertEquals(expResult, result, 0.0);
        
    }

    /**
     * Test of ingresar method, of class CCuenta.
     */
    public void testIngresar() throws Exception {
        System.out.println("ingresar");
        double cantidad = 1500.0;
        CCuenta instance = new CCuenta();
        instance.ingresar(cantidad);
        
        
    }

    /**
     * Test of retirar method, of class CCuenta.
     */
    public void testRetirar() throws Exception {
        System.out.println("retirar");
        double cantidad = 500.0;
        CCuenta instance = new CCuenta();
        instance.retirar(cantidad);
       
    }

    /**
     * Test of obtenerCuenta method, of class CCuenta.
     */
    public void testObtenerCuenta() {
        System.out.println("obtenerCuenta");
        CCuenta instance = new CCuenta();
        String expResult = "";
        String result = instance.obtenerCuenta();
        assertEquals(expResult, result, null);
        
         
    }
     public void testRetirarYIngresar() throws Exception {
       double cantidadIngresar = 1500;
       double cantidadRetirar = 500;
       CCuenta instance = new CCuenta();
       instance.ingresar(cantidadIngresar);
       instance.retirar(cantidadRetirar);
       String expResult = "";
        double result = instance.estado(); 
       assertEquals(expResult, result, 1000.0);
       System.out.println("Cantidad despues de ingresar"+ instance.estado());
       
    }
}
